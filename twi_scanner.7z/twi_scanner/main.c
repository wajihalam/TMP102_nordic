#include <stdio.h>
#include "boards.h"
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
#include "nrf_delay.h"



#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

/* TWI instance ID. */
#if TWI0_ENABLED
#define TWI_INSTANCE_ID     0
#elif TWI1_ENABLED
#define TWI_INSTANCE_ID     1
#endif

 /* Number of possible TWI addresses. */
 #define TWI_ADDRESSES      127
 #define TMP_ADDRESS       (0x48)

/* TWI instance. */
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);


/**
 * @brief TWI initialization.
 */
void twi_init (void)
{
    ret_code_t err_code;

    const nrf_drv_twi_config_t twi_config = {
       .scl                = 27,
       .sda                = 02,
       .frequency          = NRF_DRV_TWI_FREQ_100K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .clear_bus_init     = false
    };

    err_code = nrf_drv_twi_init(&m_twi, &twi_config, NULL, NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_twi_enable(&m_twi);
}

void read_tmp102(void)
 {
    uint8_t tmp_data[2];
    uint8_t tmp_data_le[2];
    uint16_t *tmp = (uint16_t *) &tmp_data_le[0];

    nrf_drv_twi_rx(&m_twi, TMP_ADDRESS, tmp_data, 2);

    tmp_data_le[0] = tmp_data[1];
    tmp_data_le[1] = tmp_data[0];
    float tmp102 = (*tmp >> 4) * 0.0625;

    NRF_LOG_INFO("DATA: 0x%x, 0x%x", tmp_data[0], tmp_data[1]);
    NRF_LOG_INFO("TMP: " NRF_LOG_FLOAT_MARKER  "\r\n", NRF_LOG_FLOAT(tmp102));
    NRF_LOG_FLUSH();
 }


/**
 * @brief Function for main application entry.
 */
int main(void)
{
    ret_code_t err_code;
    uint8_t address = 0x48;
    uint8_t sample_data;
    bool detected_device = false;

    APP_ERROR_CHECK(NRF_LOG_INIT(NULL));
    NRF_LOG_DEFAULT_BACKENDS_INIT();

    NRF_LOG_INFO("TWI scanner started.");
    NRF_LOG_FLUSH();
    twi_init();

    //for (address = 1; address <= TWI_ADDRESSES; address++)
    //{
        err_code = nrf_drv_twi_rx(&m_twi, address, &sample_data, sizeof(sample_data));
        if (err_code == NRF_SUCCESS)
        {
            detected_device = true;
            NRF_LOG_INFO("TWI device detected at address 0x%x.", address);
        }
        NRF_LOG_FLUSH();
    //}

    if (!detected_device)
    {
        NRF_LOG_INFO("No device was found.");
        NRF_LOG_FLUSH();
    }

    read_tmp102();
    while (true)
    {
        /* Empty loop. */
        read_tmp102();
        nrf_delay_ms(500);
    }
}

/** @} */
